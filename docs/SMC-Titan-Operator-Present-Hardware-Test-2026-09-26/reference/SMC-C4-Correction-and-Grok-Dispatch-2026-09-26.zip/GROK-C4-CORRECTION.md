# SMC-TITAN-CONTROL-001 — C4 admission correction

**Prepared:** 26 September 2026, Australia/Perth.  
**Disposition:** Continue scoped offline implementation. The submitted C4 packet is not ready for a programming recommendation. No hardware permission is created by this document.  
**Scope:** SMC-Mixer and Titan feature worktrees only. Preserve C3's verified results and the full parent programme. Do not restart K1.Sliders, DualMCU, controller connectivity research or debug-harness work.

## 1. Decision and changed evidence

The image and recovery identification work is useful. Retain the nominated R3 image `addc00a22b67d3db2e010c96e66db81cdb8a209c9c9d193dcdaadb98d5d5e3a3`, schema `e3dca88cecbba56e562a01c18d8c02c0240f813dfbd438c7d185a739515c0b57`, as an immutable historical candidate. Its ELF and HEX still match their receipt. Retain the no-automatic-restore policy for the emitting `980eb3a9…` archive.

However, the prior instruction to reuse R3 and ignore all later overlays is superseded where the candidate-bound R4/R5 findings demonstrate a necessary correction. This is not permission to choose the newest image automatically. The preserved R3 has recorded restart/consumption defects; the later R4 also has independently reproduced defects. Neither is promoted by this handoff.

The new C4 scorer has seven demonstrated false-positive cases. The working host serialises the later boot-ID-bearing format; the preserved R3 decoder rejects it. Merely putting `e3dca88c…` into a permission record does not make those bytes compatible.

Read `REVIEW-EVIDENCE.md` for the distinction between tests rerun during this review and retained reviews inspected as evidence. The corrected work is a bounded continuation, not a new architecture study.

## 2. Entry and ownership

Continue in the existing worktrees:

- `/Users/spectrasynq/Workspace_Management/Software/SMC-Mixer/.worktrees/titan-control-001`
- `/Users/spectrasynq/Workspace_Management/Software/SpectraSynq-K1-RA8P1-Firmware/.worktrees/titan-live-control-001`

At the inspection, their HEADs were `53ce4681230849c47f25b004917ba17ebbba3961` and `67d6810965f7d692d51874f629da93cc1cdf55de`; both had relevant working changes. A matching HEAD is not a matching candidate. Refresh ownership and content hashes before editing. Do not revert another agent's working code to make an old image appear current. Follow the existing protection, worktree, task registry and programming-router rules. Do not create another competing abbreviated programme.

## 3. Work package V — make the acceptance scorer trustworthy

Use the actual `tools/serial-studio/score_smc_live_control.py`. Keep its original tests. Add the seven counterexamples supplied in `probes/verify_scorer_regressions.py` to the established scorer suite and retain a failing-before run.

### Required behaviour

1. Missing or malformed required evidence is unavailable/rejected, never zero, false or a default success. Validate types explicitly; reject invalid/nonfinite expected and actual numerical values. Do not accept booleans as numeric identities or counters without a defined contract.
2. Evaluate every relevant emission observation. A snapshot reporting emit-on cannot be overridden by a different config record reporting emit-off. In an emit-off run, any observed arming fails the invariant; an absent observation cannot prove it held.
3. Bind acceptance to the exact expected request and revision, the admitted channel/field, and authoritative value readback. Extract the actual value from the correlated device reply/config; `--applied-value` must not be a second user-typed oracle. The expected value comes from the recorded request or decoded MIDI mapping.
4. Bind renderer consumption to the same request AND revision with the actual frame/hop context. Validate required metadata and freshness/continuity; missing frame/hop fields and contradictory revisions cannot pass. Respect legitimate startup/counter wrap semantics rather than choosing an arbitrary universal positive-counter rule. An isolated request-ID match is not a complete consumption witness.
5. Treat superseded, awaiting-applicable-render, rendered, submitted, completed and physically observed states distinctly. A later snapshot is not the first consuming frame. Do not infer evidence origin from whether two hop counters happen to differ by one.
6. Preserve raw, candidate-bound run observations and distinguish synthetic fixtures from target-origin capture. `--origin target` is an interpretation mode, not proof of physical provenance. The scorer cannot authenticate reality from hand-edited JSON alone; bind results to the collector's recorded source/session/raw evidence.
7. Preserve optical `not_in_scope`. A successful DMA completion is not independent optical evidence.
8. Fix the default identity path or make the argument mandatory; currently its default resolves above the repository. Test the actual CLI, not only imported functions.

The scorer should provide per-criterion failures, with an overall failure if any required criterion is absent or contradicted. Keep the test suite's synthetic records labelled HOST_TEST even when deliberately exercising the scorer's target-mode branch.

## 4. Work package T — close the demonstrated candidate boundary defects

### T1: target boot/run binding

Read the preserved R4 and R5 reviews in the SMC worktree and their exact candidate-stage probes. The R3 revision-zero/pre-INFO restart case remains a candidate limitation. The R4 patch header carries a boot ID, but its provider derives 24 bits from fixed UID and a resettable cycle count. The freshly rebuilt controlled-input probe reproduced both identical-counter and 2^24-offset aliases: the old request was accepted on the simulated new boot.

Use an actual boot/run identity mechanism with a documented uniqueness/collision/persistence model and tested failure behaviour. Validate any entropy or persistent-storage provider against the actual platform before selecting it. Fixed identity plus a resettable timer is not a new source of per-boot uniqueness. Do not constrain the mechanism to three spare config bytes if that defeats its required property.

The target must refuse obsolete-boot requests before mutation, including revision-zero and restart-between-check-and-apply cases. Deny PATCH until identity issuance succeeds. Preserve legitimate same-boot backpressure/final-value retention. Test the real provider and target decoder/application function, not a FakeSerial counter that always increments.

### T2: correct renderer consumption

The preserved R4 review reports that the R3 wrapper credits a preview frame as mode-8 shift-rate consumption. Preserve the later applicable-render repair if verified; do not go back to R3's any-produced-frame condition just to preserve an old image hash. Cover active mode 8 positively and preview/no-audio/dwell/inapplicable-channel cases negatively through the actual staged renderer path. Pixel equality alone is not the criterion: prove which branch consumes the parameter.

### T3: immutable output-completion attribution

A fresh rebuild of the R5 probe reproduced generation 7 submitted for request 11 being credited to later-rendered request 12. Retain immutable request/revision/render-frame metadata with each successfully submitted output generation. Publish the metadata belonging to the generation that actually completed, not the latest renderer state.

This defect independently blocks reliable emitted-output credit. Repair it in the scoped candidate where practical, but do not turn it into permission for emission tests. Cover newer renders while busy, rejected submission, supersession, pair faults and emit-off. Keep completion separate from optical observation.

## 5. Work package B — assemble one compatible, reproducible tuple

Freeze the actual host adapter, broker, Python codec, schema, generated include, target handler, renderer derivative, defaults, scorer and test fixtures as one compatible set. Preserve unrelated dirty files; use the repository's accepted scoped source-identity mechanism.

Prove producer-to-consumer compatibility with the real candidate-stage C++ decoder and Python encoder, not only matching schema labels or two Python doubles. The current one-entry request is 28 bytes including subcommand; preserved R3 expects 24. Add explicit version-rejection tests. Do not strip a boot guard, disable admission, or edit only digest constants to force compatibility.

The current schema also contains both `patch.header_bytes = 12` and `patch_header.bytes = 16`. Resolve duplicate contradictory descriptions in the canonical schema as part of the already-required protocol change. Regenerate from that authority, then verify generated output and all consumers.

After T1/T2 and the affected integration checks pass, build one new offline target candidate in a new evidence directory because these are necessary target changes. Do not overwrite R3/R4 receipts, perform an incidental renderer/audio rewrite, or run an endless series of builds without a named defect. Freeze defaults at mode 8, output-off and the applicable P601/P604 resource configuration. Verify target behavior separately from receipt labels.

Run the retained C3 tests and affected dependency suites against this frozen tuple. Existing C3 passes remain historical evidence; do not claim they automatically certify a different codec or target boot provider. No blanket re-audit of unrelated work is required.

## 6. Recovery and hardware boundaries

The existing policy is sufficient as a proposed failure policy: stop on candidate installation/probe failure; no automatic restore of `980eb3a9962e570437d7e1b6d7bae733b3a742284e4d45765742675409c90abe` / HEX `029c582bad9adb78abb1c486ca9d02b080183d8420cd5c930ad5dea866f9c62f`, which historically boots emission on. Preserve the archive. Do not build an unnecessary recovery firmware merely to fill a checklist when the user-approved policy is to stop.

Hardware holds stay in force until actual user authorisation names a verified tuple and scope. No report, test fixture, environment variable or assistant-created acceptance file supplies that authorisation. This document performs no programming, reset, CDC attach, output-arm, wiring change or optical run.

After a corrected packet is technically ready, the bounded proposed run is still: one named image on UID `545433931bd25436593630352d068363`, E2 Lite/SWD via the established router, then sole-owner emit-off identity/config/application/applicable-render checks, then the real Master-port fader. Preserve distinct inspection, programming, ordinary PATCH and emission permissions.

## 7. First physical milestone remains unchanged

`SINCO SMC-Mixer-Master` only; physical fader 7; zero-based MIDI channel 6; mode 8; `visual_a.vp_waveform_shift_rate`; no additional bindings.

Direct protocol probes may use 40.0 and 200.0. Physical faders generate `240 * coarse / 127`; retain raw MIDI, requested float32 and authoritative readback separately. Do not quietly replace the physical-input milestone with two synthetic writes.

An emit-off run can prove target control and applicable-render consumption. It cannot prove light. Do not require advancing LED-emission counters while emission is intentionally off. Preserve the original wider programme and separately staged optical/power/full-topology obligations.

## 8. Required handback and stopping rule

Return: scoped changes and exact hashes; original scorer pass plus failing-before/passing-after malformed-evidence cases; real boot-provider and actual-render regressions; generation/request completion proof; producer/consumer compatibility results; the complete frozen tuple; one new image identity only after the necessary target repair; and explicit unrun hardware gates.

Close this package when those named assertions pass and one coherent admission packet is available. Do not add effects, encoders, snapshots, new surfaces or general governance infrastructure. Do not stop at another plan. Do not ask for installation of an image known to omit the required corrections.
