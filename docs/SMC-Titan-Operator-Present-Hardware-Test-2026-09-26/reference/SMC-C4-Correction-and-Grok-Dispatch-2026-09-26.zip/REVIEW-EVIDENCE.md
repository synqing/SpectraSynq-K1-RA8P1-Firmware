# SMC C4 admission review — evidence

**Observed:** 26 September 2026, 15:59:56–16:01:35 Australia/Perth, via Remote Desktop Commander on the user's Mac.  
**Review boundary:** source reads, artifact hashing, existing scorer-test rerun, malformed-record scorer tests and host C++ compilation/execution only. No real MIDI, CDC, SWD, target reset, firmware programming or emission operation. No product source was edited.

The raw Mac-side audit is `/tmp/smc-c4-scorer-review-_bq_t1rr/`. The notes and reduced result files here are a transcription/summary of executed tool output, not a claim that the entire remote audit directory was copied. The included Python reproducer is a packaged equivalent of the executed scorer probes; it was not executed again against remote sources during packaging.

## E1 — nominated image and packet

Titan worktree: `/Users/spectrasynq/Workspace_Management/Software/SpectraSynq-K1-RA8P1-Firmware/.worktrees/titan-live-control-001`.

SMC worktree: `/Users/spectrasynq/Workspace_Management/Software/SMC-Mixer/.worktrees/titan-control-001`.

HEADs observed: Titan `67d6810965f7d692d51874f629da93cc1cdf55de`; SMC `53ce4681230849c47f25b004917ba17ebbba3961`. Both contain further relevant working changes. The packet is `docs/evidence/SMC-TITAN-CONTROL-001/c4-readiness-20260926/`, with `CANDIDATE-IDENTITY.json`, `RECOVERY-IDENTITY.json` and `CANDIDATE-RECOVERY-RUN-SCOPE.md`.

Freshly hashed preserved R3 artifacts:

| Artifact | Actual SHA-256 | Receipt match |
|---|---|---|
| `offline-arm-build-20260926-r3/rtthread.elf` | `62859ec129e9367309df0a7decf4c57844c4b4b0017234a5d788cf145953758d` | true |
| `offline-arm-build-20260926-r3/rtthread.hex` | `ca3c671e9b7a647b425d99715e23e85bf67b0b32e8ffab22f44415a232ba3b93` | true |

The packet names build `addc00a22b67d3db2e010c96e66db81cdb8a209c9c9d193dcdaadb98d5d5e3a3`, schema `e3dca88cecbba56e562a01c18d8c02c0240f813dfbd438c7d185a739515c0b57`, mode 8, emission off, P601/GPT6 and P604/GPT8. This review did not rebuild the image, rehash its entire declared-source map or inspect the live board. The previous 120-input verification remains its dated historical result.

The packet explicitly prohibits automatic restoration of the emitting `980eb3a9…` archive. That proposed failure policy need not be expanded into a new recovery-development programme. It is not itself permission to install anything.

## E2 — scorer's own tests pass, but seven additional checks fail

Executed command:

```text
python3 -B <Titan worktree>/tools/serial-studio/tests/test_c4_scorer.py
```

Result: exit 0, `C4_SCORER_PASS` (eight test functions in the inspected runner).

Then imported the actual scorer and used the packet's actual candidate-identity JSON. All records were deliberately synthetic HOST_TEST inputs exercising `origin="target"`. No record in this test is evidence of a real target run. Positive control: matching request 7/revision 3, mode 8, emit 0, rendered frame 3/hop 9, and expected/supplied value 40; returned `ok=true`.

| Negative case | Intended criterion | Actual scorer output |
|---|---|---|
| Remove `emit_on` and `last_emitted_request_id` | Missing emission evidence cannot prove off | `ok=true`, `emit_held_off=true` |
| Set `emit_on="unavailable"` | Malformed emission evidence cannot prove off | `ok=true`, `emit_held_off=true` |
| Snapshot `emit_on=1`, config `emit_on=0` | Contradictory emission observations cannot pass an emit-off run | `ok=true`, `emit_held_off=true` |
| Accepted revision 3, rendered revision 2 | Consumption must match the accepted revision | `ok=true`, `consumed="consumed"` |
| Matching rendered ID but frame=0 and hop=0 | The specific fixture has no valid consuming-frame witness | `ok=true`, `consumed="consumed"` |
| Expected value 40, no supplied actual value | Requested value application remains unverified | `ok=true`, `applied="applied"` |
| Config says actual motion 240, expected=40 and CLI-supplied actual=40 | Authoritative config must not be bypassed by a duplicate expected value | `ok=true`, `applied="applied"` |

These are seven counterexamples to the advertised scorer guarantees, not seven on-device failures. The full outputs are in remote `scorer-probe-results.json`; `scorer-results-summary.json` here is the reduced result.

Source locations in `tools/serial-studio/score_smc_live_control.py`:

- Lines 80–82: `_int` defaults missing/malformed emission to zero; config can overwrite snapshot emission.
- Lines 96–150: acceptance/consumption scoring does not compare `last_rendered_revision` or validate `last_rendered_frame`.
- Lines 111–115: value verification runs only when both optional scalar arguments are supplied, and does not extract the actual field from config.
- Lines 17–20 and 172: the default identity path resolves under `<Titan repo>/.worktrees/docs/...`, not the feature worktree. `DEFAULT_IDENTITY.exists()` returned false. The packet's explicit `--identity` avoids this particular CLI problem.

## E3 — current host PATCH and preserved R3 decoder are incompatible

The actually imported host `tools/serial-studio/live_protocol.py` reads schema `af180050ff21623abdee6c5d3d505e26a683d0311f15dba44617a95de0a15501` from its working-tree contract. Its `pack_patch` uses `<IIHHI`: revision, request ID, entry count, channel and boot ID. One field creates 28 bytes including the 4-byte subcommand.

Recorded example (revision 2, request 7, channel A, boot ID 1, motion 40):

```text
08000000020000000700000001000000010000000700010000002042
```

The preserved R3 stage's `k1_live_protocol.cpp:398–429` decodes a 12-byte PATCH header and requires body size exactly `12 + count*8` (line 413). Its fixture handler removes the 4-byte subcommand before calling this decoder. It therefore expects 24 total bytes for one field.

A small C++ harness was compiled with the actual preserved R3 `stage/src/k1_live_protocol.cpp` and headers. It supplied a valid R3-formatted body and the current host-formatted body. Compile exit 0; run exit 0; output:

```text
R3_PAYLOAD accepted=1; CURRENT_HOST_PAYLOAD accepted=0
```

Exit 0 means the incompatibility reproducer behaved as expected, not that the mixed tuple is acceptable. Nothing was sent to hardware. A copied digest cannot repair the format difference. The current JSON contract also simultaneously lists `patch.header_bytes=12` and `patch_header.bytes=16`; this contradiction was directly read, not inferred from a failed build.

## E4 — why the later target changes cannot simply be dismissed

Read the existing SMC worktree review `docs/execution/SMC-TITAN-CONTROL-001-REVIEW-R4-20260926.md` and its retained evidence under:

`/Users/spectrasynq/Library/Logs/SpectraSynq/SMC-Mixer/20260926-140548-fourth-review/`.

That candidate-bound review reports two R3 defects:

1. At boot revision 0, an old queued movement applies after a same-image restart before the next INFO poll.
2. A no-audio preview frame can be credited as mode-8 motion consumption, even though that branch does not consume the motion parameter.

The raw retained outputs read in this review include:

```text
old_queued_move_applied: true; target: 240; session_unchanged: true
PREVIEW_CONSUMPTION produced=1 preview=1 reported_request=77 reported_hop=0 reported_frame=1 changed_pixels=0
```

Those two R3 campaigns were inspected as existing evidence and were NOT rerun during this turn. The preview branch observation, not mere pixel equality, is the load-bearing claim. These documented failures are a reason to supersede the old blanket 'do not pursue the later changes' instruction, while retaining the original evidence and C3's bounded historical passes.

## E5 — later R4 also has reproduced defects; do not blindly promote it

Read `SMC-TITAN-CONTROL-001-REVIEW-R5-20260926.md` and the preserved probe under:

`/Users/spectrasynq/Library/Logs/SpectraSynq/SMC-Mixer/20260926-155454-fifth-review/`.

This turn recompiled `boot-and-pair-probe.cpp` using its recorded command against preserved R4 `stage/src/k1_live_protocol.cpp`, changing ONLY the executable output path into the audit scratch directory. The two extracted functions in the probe, `live_ensure_boot_id()` and `palette_pair_poll()`, were checked for exact text equality to the corresponding R4 staged functions; both comparisons returned true.

Compile exit 0; run exit 0; output:

```text
BOOT_DIFFERENT_COUNTER_CONTROL rejected=1
BOOT_IDENTICAL_COUNTER old_id=5326009 new_id=5326009 accepted=1 target=240.0
BOOT_COUNTER_PLUS_2_POW_24 old_id=5326009 new_id=5326009 accepted=1 target=240.0
PAIR_COMPLETION_AFTER_NEW_RENDER submitted_request=11 completed_generation=7 last_rendered=12 credited_request=12
PAIR_UNCHANGED_RENDER_CONTROL credited=21
```

These are controlled host reproductions of candidate functions. They do not measure the frequency of real boot-ID collisions, exercise live DMA or establish an optical fault. The run intentionally asserts that the defects reproduce, so its zero exit is NOT a readiness PASS.

The boot provider mixes fixed UID with a cycle counter and truncates to 24 bits: repeated counter inputs repeat the ID, and a difference of 2^24 aliases. The completion path checks a completed generation but credits the latest renderer request, not the stored pending request associated with that generation.

The later R4 build identified by the retained review is `51b73cdb700cb40d2a542a65cefd16415463c0e308f66c64db17d5f23365bfed`. This review did not rehash its whole ELF/HEX or promote it. The relevant staged functions and protocol were used in the fresh host reproducer.

## E6 — decision and source stability

Engineering recommendation: do not issue installation GO on this packet. Finish the scorer repair, actual boot/run binding, applicable-render and completion attribution corrections, then freeze and test one mutually compatible host/target tuple. A necessary target change justifies a new build; arbitrary rebuilding or switching to the newest directory does not.

C3 remains credited for the cases and source tuple that passed. This review did not rerun all C3 suites, nor does it claim their prior passing results were fabricated. The candidate-default restart/provider counterexamples extend the affected boundary and must be carried into the corrected tuple's regressions.

Selected source SHA-256 values at start and end matched:

| Source | SHA-256 |
|---|---|
| Titan scorer | `3f3779133a0d926ba65482119f5490cbc3d9a00876296507a5b1f1092a1e85dd` |
| Titan scorer tests | `39c28eb1e0bb9fce10f00dda1db9cb4ae351d8cf396dbb0d53fe44335466a5bc` |
| Titan Python codec | `cb2334a8f6898ee00fbd664cefd4ea2d20393bc3086d0dee768d338fbacb566d` |
| Titan schema | `af180050ff21623abdee6c5d3d505e26a683d0311f15dba44617a95de0a15501` |
| Titan broker | `486509d3737c9d42e900efc048f9a2f11f2316ebe8f6485fb77e7dc06faf53ba` |
| Titan control server | `802bc9c1ff6d0a5d851e800f700d42eb3a44d95326574e92489cba4724ec7212` |
| SMC adapter | `de2165a141eacbdd153a2179a10a0d73e053e44939cac1641e0ca9a8d8567c5f` |

Audit scratch process exited normally. No repository edit or device state change was made by this review.
