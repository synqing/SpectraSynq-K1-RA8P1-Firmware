# SMC C4 admission correction — 26 September 2026

Read `GROK-C4-CORRECTION.md` first, then `REVIEW-EVIDENCE.md`.

The correction supersedes only the previous blanket R3-reuse/no-later-changes direction where new candidate-bound defects establish the need. The original programme, SMC migration and valid C3 evidence remain in force. The previous C4 package is preserved unchanged under `reference/`; its historical instructions are not a competing current GO.

This package is review evidence and onward implementation guidance, not firmware, installation permission or an accepted checkpoint. It includes an offline scorer reproducer. No remote product source was edited during this review.

The included probe tests the existing scorer function interface; after refactoring that interface, migrate the same assertions into the actual maintained scorer suite rather than adding compatibility shims just to satisfy this script.
