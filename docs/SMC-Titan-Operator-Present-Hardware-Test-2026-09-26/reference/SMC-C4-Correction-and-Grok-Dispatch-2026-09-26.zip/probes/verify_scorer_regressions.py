#!/usr/bin/env python3
"""Offline scorer regression probe. Does not open MIDI, serial or any target.

Synthetic records deliberately exercise the scorer's target-mode branch.
Every result from THIS probe is HOST_TEST, not TARGET_RUNTIME evidence.
Exit 1 means at least one desired regression assertion fails on the scorer.
"""
from __future__ import annotations
import argparse
import importlib.util
import json
import hashlib
from pathlib import Path
from typing import Any


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--titan-root', type=Path, required=True)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    root = args.titan_root.resolve()
    source = root / 'tools/serial-studio/score_smc_live_control.py'
    identity_path = root / 'docs/evidence/SMC-TITAN-CONTROL-001/c4-readiness-20260926/CANDIDATE-IDENTITY.json'
    if not source.is_file() or not identity_path.is_file():
        parser.error('Scorer or nominated C4 identity file is missing at the specified worktree.')
    spec = importlib.util.spec_from_file_location('reviewed_smc_scorer', source)
    if spec is None or spec.loader is None:
        raise RuntimeError('Could not load scorer module')
    scorer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(scorer)
    identity = scorer.load_identity(identity_path)
    fixture: dict[str, Any] = {
        'uid': identity['uid'], 'build_sha256': identity['build_id'],
        'schema_sha256': identity['schema_sha256'], 'emit_on': 0, 'mode_id': 8,
        'accepted_request_id': 7, 'accepted_revision': 3,
        'last_rendered_request_id': 7, 'last_rendered_revision': 3,
        'last_rendered_frame': 3, 'last_rendered_hop': 9,
        'last_emitted_request_id': 0, 'hop_sequence': 40, 'hops_consumed': 9,
        'config_revision': 3, 'valid': True, 'stale': False,
    }
    cases: list[dict[str, Any]] = []

    def check(name: str, snap: dict[str, Any], *, config=None, actual=40.0, should_pass=False):
        got = scorer.score_record(
            identity=identity, snapshot=snap, config=config, origin='target',
            expect_request_id=7, expect_value=40.0, applied_value=actual,
        )
        cases.append({'case': name, 'expected_ok': should_pass,
                      'observed': got, 'check_pass': got['ok'] == should_pass})

    check('positive_control', dict(fixture), should_pass=True)
    snap = dict(fixture); snap.pop('emit_on'); snap.pop('last_emitted_request_id')
    check('missing_emit_evidence', snap)
    snap = dict(fixture); snap['emit_on'] = 'unavailable'
    check('malformed_emit_evidence', snap)
    snap = dict(fixture); snap['emit_on'] = 1
    check('contradictory_emit_snapshot_and_config', snap, config={'emit_on': 0, 'mode_a': 8})
    snap = dict(fixture); snap['last_rendered_revision'] = 2
    check('wrong_rendered_revision', snap)
    snap = dict(fixture); snap['last_rendered_hop'] = 0; snap['last_rendered_frame'] = 0
    check('no_render_frame_or_hop', snap)
    check('missing_actual_value', dict(fixture), actual=None)
    check('wrong_config_value_masked_by_cli', dict(fixture), config={
        'mode_a': 8, 'emit_on': 0, 'revision': 3, 'last_patch_request_id': 7,
        'visual_a': {'vp_waveform_shift_rate': 240.0},
    })
    report = {
        'evidence_class': 'HOST_TEST', 'hardware_io': False,
        'scorer_source': str(source),
        'scorer_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'cases': cases, 'all_checks_pass': all(row['check_pass'] for row in cases),
    }
    text = json.dumps(report, indent=2) + '\n'
    print(text, end='')
    if args.output:
        args.output.write_text(text)
    return 0 if report['all_checks_pass'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
